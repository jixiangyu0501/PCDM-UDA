import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
import mmd
import numpy as np
from sklearn import metrics
from net import DSAN, DCRN_02F, DCD
import time
import utils
from torch.utils.data import TensorDataset, DataLoader
from contrastive_loss import SupConLoss
from config_YC import *
from sklearn import svm
import cleanlab
from pksolver import PK_solver
from scipy.spatial.distance import cdist
from sklearn.metrics import confusion_matrix

def obtain_label(mem_P, all_fea, pk_solver):
    predict = mem_P.argmax(-1)
    # accuracy = torch.sum(torch.squeeze(predict).float() == all_label).item() / float(all_label.size()[0])
    # matrix = confusion_matrix(all_label, torch.squeeze(predict).float())
    # avg_accuracy = (matrix.diagonal() / matrix.sum(axis=1)).mean()

    # update labels with prior knowledge
    probs = mem_P
    # first solve without smooth regularization
    pred_label_PK = pk_solver.solve_soft(probs)

    # acc_PK = np.sum(pred_label_PK == all_label.float().numpy()) / float(all_label.size()[0])
    # matrix_PK = confusion_matrix(all_label.float().numpy(), pred_label_PK)
    # avg_acc_PK = (matrix_PK.diagonal() / matrix_PK.sum(axis=1)).mean()
    # log_str = 'PK Accuracy = {:.2f}% -> {:.2f}%    Per_class_accuracy = {:.2f}% -> {:.2f}%'.format(accuracy * 100, acc_PK * 100, avg_accuracy * 100, avg_acc_PK * 100)
    # logging.info(log_str)

    if pk_knn > 0 and all_fea is not None:
        # now solve with smooth regularization
        predict = predict.cpu().numpy()
        all_fea = torch.cat((all_fea, torch.ones(all_fea.size(0), 1)), 1)
        all_fea = (all_fea.t() / torch.norm(all_fea, p=2, dim=1)).t()
        all_fea = all_fea.float().cpu().numpy()

        idx_unconf = np.where(pred_label_PK != predict)[0]
        knn_sample_idx = idx_unconf
        idx_conf = np.where(pred_label_PK == predict)[0]

        if len(idx_unconf) > 0 and len(idx_conf) > 0:
            # get knn of each samples
            dd_knn = cdist(all_fea[idx_unconf], all_fea[idx_conf], distance)
            knn_idx = []
            K = pk_knn
            for i in range(dd_knn.shape[0]):
                ind = np.argpartition(dd_knn[i], K)[:K]
                knn_idx.append(idx_conf[ind])

            knn_idx = np.stack(knn_idx, axis=0)
            knn_regs = list(zip(knn_sample_idx, knn_idx))
            pred_label_PK = pk_solver.solve_soft_knn_cst(probs, knn_regs=knn_regs)


        # acc_PK = np.sum(pred_label_PK == all_label.float().numpy()) / len(all_fea)
        # matrix_PK = confusion_matrix(all_label.float().numpy(), pred_label_PK)
        # avg_acc_PK = (matrix_PK.diagonal() / matrix_PK.sum(axis=1)).mean()
        # if da == 'pda':
        #     avg_acc_PK = 0
        # log_str = 'PK Accuracy = {:.2f}% -> {:.2f}%    Per_class_accuracy = {:.2f}% -> {:.2f}%'.format(accuracy * 100, acc_PK * 100, avg_accuracy * 100, avg_acc_PK * 100)
        # logging.info(log_str)

    return pred_label_PK.astype('int')

def get_probs(data_loader, data_loader_t):#使用给定的数据加载器data_loader和data_loader_t来获取样本的概率。
    train_features, train_labels = utils.extract_embeddings(feature_encoder, data_loader)
    clt = svm.SVC(probability=True)
    clt.fit(train_features, train_labels)
    test_features, test_labels = utils.extract_embeddings(feature_encoder, data_loader_t)
    probs = clt.predict_proba(test_features)#使用训练好的分类器clt对测试样本的特征向量进行预测，得到预测的概率probs。
    return probs

##################################
data_path_t = './datasets/YC/GF_YC_data.mat'
label_path_t = './datasets/YC/GF_YC_gt.mat'
data_path_s = './datasets/YC/ZY_YC_data147.mat'
label_path_s = './datasets/YC/ZY_YC_gt7.mat'

data_s,label_s = utils.load_data_GF(data_path_s,label_path_s)
data_t,label_t = utils.load_data_GF(data_path_t,label_path_t)
print(data_s.shape,label_s.shape)
print(data_t.shape,label_t.shape)

# Loss Function
crossEntropy = nn.CrossEntropyLoss().cuda()
domain_criterion = nn.BCEWithLogitsLoss().cuda()
ContrastiveLoss_s = SupConLoss(temperature=0.1).cuda()
ContrastiveLoss_t = SupConLoss(temperature=0.1).cuda()
DSH_loss = utils.Domain_Occ_loss().cuda()
criterion_w = utils.Weighted_CrossEntropy

acc = np.zeros([nDataSet, 1])
A = np.zeros([nDataSet, CLASS_NUM])
k = np.zeros([nDataSet, 1])
best_predict_all = []
best_acc_all = 0.0
best_G,best_RandPerm,best_Row, best_Column,best_nTrain = None,None,None,None,None

def get_probs(data_loader, data_loader_t):#使用给定的数据加载器data_loader和data_loader_t来获取样本的概率。
    train_features, train_labels = utils.extract_embeddings(feature_encoder, data_loader)
    clt = svm.SVC(probability=True)
    clt.fit(train_features, train_labels)
    test_features, test_labels = utils.extract_embeddings(feature_encoder, data_loader_t)
    probs = clt.predict_proba(test_features)#使用训练好的分类器clt对测试样本的特征向量进行预测，得到预测的概率probs。
    return probs

def clean_sampling_epoch(labels, probabilities, output):#对标签和概率进行清洗和采样
    labels = np.array(labels)
    probabilities = np.array(probabilities)
    print("start clean samples")
    print(labels.shape)
    print(probabilities.shape)
    ###################
    # 过滤样本的方法
    ###################
    label_error_mask = np.zeros(len(labels), dtype=bool)
    label_error_indices = cleanlab.latent_estimation.compute_confident_joint(
        labels, probabilities, return_indices_of_off_diagonals=True
    )[1]#计算置信矩阵，并返回置信错误样本的索引。
    for idx in label_error_indices:#基于类别来确定噪声样本的索引。
        label_error_mask[idx] = True

    label_errors_bool = cleanlab.pruning.get_noise_indices(labels, probabilities, prune_method='prune_by_class',n_jobs=1)
    # label_errors_bool = cleanlab.filter.find_label_issues(labels, probabilities,n_jobs=1)

    ordered_label_errors = cleanlab.pruning.order_label_errors(
        label_errors_bool=label_errors_bool,
        psx=probabilities,
        labels=labels,
        sorted_index_method='normalized_margin',
    )

    true_labels_idx = []  # 置信样本的索引
    all_labels_idx = []  # 所有标签的索引
    print('len of all_lables', len(labels))
    print('len of errors_lables', len(ordered_label_errors))
    for i in range(len(labels)):
        all_labels_idx.append(i)
    if len(ordered_label_errors) == 0:
        true_labels_idx = all_labels_idx
    else:
        for j in range(len(ordered_label_errors)):
            all_labels_idx.remove(ordered_label_errors[j])
            true_labels_idx = all_labels_idx
    print('len of true_lables', len(true_labels_idx))
    # weights
    orig_class_count = np.bincount(labels, minlength=CLASS_NUM)
    train_bool_mask = ~label_errors_bool
    imgs = [labels[i] for i in range(len(labels)) if train_bool_mask[i]]
    clean_class_counts = np.bincount(imgs, minlength=CLASS_NUM)
    print(orig_class_count)
    print(clean_class_counts)
    class_weights = torch.Tensor(orig_class_count / clean_class_counts).cuda()

    print(class_weights)
    # 获取目标域中对应的置信样本和伪标签
    target_labels = []
    target_datas = []

    for i in range(len(true_labels_idx)):
        if output[true_labels_idx[i]] >= 0.8:
            target_datas.append(testX[true_labels_idx[i]])
            target_labels.append(labels[true_labels_idx[i]])

    target_datas = np.array(target_datas)
    target_labels = np.array(target_labels)
    ####################
    # 输出所挑选的置信样本中真正正确的样本所占的比重
    ######################
    right_score = 0

    for i in range(len(true_labels_idx)):
        # testY true label
        if testY[true_labels_idx[i]] == labels[true_labels_idx[i]]:
            right_score += 1
    clean_accuracy = right_score / len(true_labels_idx)
    print('clean samples finished')
    return target_datas, target_labels, class_weights, clean_accuracy

for iDataSet in range(nDataSet):
    print('#######################idataset######################## ', iDataSet)
    utils.set_seed(seeds[iDataSet])

    trainX, trainY = utils.get_sample_data(data_s, label_s, HalfWidth, 50)
    testID, testX, testY, G, RandPerm, Row, Column = utils.get_all_data(data_t, label_t, HalfWidth)

    train_dataset = TensorDataset(torch.tensor(trainX), torch.tensor(trainY))
    test_dataset = TensorDataset(torch.tensor(testX), torch.tensor(testY))
    test_datasetidx = utils.TensorDatasetidx(torch.tensor(testX), torch.tensor(testY))

    train_loader_s = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True, drop_last=True)
    train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True, drop_last=False)
    train_loader_t = DataLoader(test_dataset,batch_size=BATCH_SIZE,shuffle=True,drop_last=True)
    test_loader = DataLoader(test_dataset,batch_size=BATCH_SIZE,shuffle=False,drop_last=False)
    test_loaderidx = DataLoader(test_datasetidx, batch_size=BATCH_SIZE, shuffle=False, drop_last=False)

    len_source_loader = len(train_loader_s)
    len_target_loader = len(train_loader_t)

    # model
    feature_encoder = DSAN(nBand, patch_size, CLASS_NUM).cuda()
    FFT_encoder = DCRN_02F(nBand, patch_size, CLASS_NUM).cuda()

    print("Training...")

    last_accuracy = 0.0
    best_episdoe = 0
    train_loss = []
    test_acc = []
    running_D_loss, running_F_loss = 0.0, 0.0
    running_label_loss = 0
    running_domain_loss = 0
    total_hit, total_num = 0.0, 0.0
    size = 0.0
    test_acc_list = []


    train_start = time.time()

    #loss plot
    loss1 = []
    loss2 = []
    loss3 = []


    for epoch in range(1, epochs + 1):
        LEARNING_RATE = lr #/ math.pow((1 + 10 * (epoch - 1) / epochs), 0.75)
        LEARNING_RATEf = lrf
        LEARNING_RATEPK = lrpk
        print('learning rate{: .4f}'.format(LEARNING_RATE))
        # optimizers = torch.optim.SGD([
        #     {'params': feature_encoder.feature_layers.parameters(),'lr': LEARNING_RATE},
        #     {'params': feature_encoder.fc1.parameters(), 'lr': LEARNING_RATE},
        #     {'params': feature_encoder.fc2.parameters(), 'lr': LEARNING_RATE},
        #     {'params': feature_encoder.head1.parameters(), 'lr': LEARNING_RATE},
        #     {'params': feature_encoder.head2.parameters(), 'lr': LEARNING_RATE},
        # ], lr=LEARNING_RATE , momentum=momentum, weight_decay=l2_decay)
        #
        # optimizer = torch.optim.SGD([
        #     {'params': feature_encoder.feature_layers.parameters(),'lr': LEARNING_RATE},
        #     {'params': feature_encoder.fc1.parameters(), 'lr': LEARNING_RATE},
        #     {'params': feature_encoder.fc2.parameters(), 'lr': LEARNING_RATE},
        #     {'params': feature_encoder.head1.parameters(), 'lr': LEARNING_RATE},
        #     {'params': feature_encoder.head2.parameters(), 'lr': LEARNING_RATE},
        # ], lr=LEARNING_RATEPK, momentum=momentum, weight_decay=l2_decay)
        optimizers = torch.optim.SGD(feature_encoder.parameters(), lr=LEARNING_RATE , momentum=momentum, weight_decay=l2_decay)
        optimizerf = torch.optim.Adam(FFT_encoder.parameters(), lr=LEARNING_RATEf,
                                     weight_decay=l2_decay)
        optimizerff = torch.optim.Adam(FFT_encoder.parameters(), lr=LEARNING_RATEf,
                                     weight_decay=l2_decay)
        optimizer = torch.optim.SGD(feature_encoder.parameters(), lr=LEARNING_RATEPK, momentum=momentum,
                                     weight_decay=l2_decay)

        # optimizera = torch.optim.Adam([
        #     {'params': feature_encoder.feature_layers.parameters(),},
        #     {'params': feature_encoder.fc1.parameters(), 'lr': LEARNING_RATE},
        #     {'params': feature_encoder.fc2.parameters(), 'lr': LEARNING_RATE},
        #     {'params': feature_encoder.head1.parameters(), 'lr': LEARNING_RATE},
        #     {'params': feature_encoder.head2.parameters(), 'lr': LEARNING_RATE},
        # ], lr=LEARNING_RATE , weight_decay=l2_decay)

        feature_encoder.train()

        # if (epoch >= train_num and epoch < epochs) and epoch % 20 == 0:
        #     print('get  fake label,ep = ', epoch)
        #     fake_label, output = utils.obtain_label(test_loader, feature_encoder)
        #
        #     print('get probs,ep=', epoch)
        #     probs = get_probs(train_loader_s, test_loader)
        #
        #     clean_datas, clean_labels, class_weights, clean_acc = clean_sampling_epoch(fake_label, probs, output)
        #
        #     clean_datasets = TensorDataset(torch.tensor(clean_datas), torch.tensor(clean_labels))
        #     clean_loader = DataLoader(clean_datasets, batch_size=BATCH_SIZE, shuffle=True, num_workers=0,drop_last=True)

        iter_source = iter(train_loader_s)
        iter_target = iter(train_loader_t)
        # if epoch >= train_num:
        #     iter_clean = iter(clean_loader)
        #     len_clean_loader = len(iter_clean)
        num_iter = len_source_loader

        for i in range(1,num_iter):
            source_data, source_label = next(iter_source)
            target_data, target_label = next(iter_target)

            if i % len_target_loader == 0:
                iter_target = iter(train_loader_t)

            # 0
            # source_data0 = utils.radiation_noise(source_data)
            # source_data0 = source_data0.type(torch.FloatTensor)
            # # 1
            # source_data1 = utils.flip_augmentation(source_data)
            # # 2
            # target_data0 = utils.radiation_noise(target_data)
            # target_data0 = target_data0.type(torch.FloatTensor)
            # # 3
            # target_data1 = utils.flip_augmentation(target_data)

            source_features, ffts, X2, source_outputs, source_out= feature_encoder(source_data.cuda())
            # _, _, _, _ ,_ = feature_encoder(source_data0.cuda())
            # _, _, _, _ ,_= feature_encoder(source_data1.cuda())
            target_features, fftt, T2, target_outputs, target_out = feature_encoder(target_data.cuda())
            # _, _, _, t1, _= feature_encoder(target_data0.cuda())
            # _, _, _, t2, _= feature_encoder(target_data1.cuda())

            # softmax_output_t = nn.Softmax(dim=1)(target_outputs).detach()
            # softmax_output_t = target_outputs.detach()
            _, pseudo_label_t = torch.max(target_outputs.detach(), 1)

            # Supervised Contrastive Loss
            # all_source_con_features = torch.cat([source_features.unsqueeze(1), ffts.unsqueeze(1)],dim=1)
            # all_target_con_features = torch.cat([target_features.unsqueeze(1), fftt.unsqueeze(1)], dim=1)

            # Loss Cls
            cls_loss = crossEntropy(source_outputs, source_label.cuda())
            # Loss Lmmd
            # lmmd_loss = mmd.lmmd(source_features, target_features, source_label,
            #                      torch.nn.functional.softmax(target_outputs, dim=1), BATCH_SIZE=BATCH_SIZE,
            #                      CLASS_NUM=CLASS_NUM)
            lmmd_loss = mmd.lmmd(source_features, target_features, source_label,
                                 torch.nn.functional.softmax(target_outputs, dim=1), BATCH_SIZE=BATCH_SIZE,
                                 CLASS_NUM=CLASS_NUM)
            lambd = 2 / (1 + math.exp(-10 * (epoch) / epochs)) - 1


            FFTX, FFTP = FFT_encoder(source_data.cuda())
            FFT_cls_loss = crossEntropy(FFTX, source_label.cuda())
            # all_source_con_features = torch.cat([source_features.unsqueeze(1), FFTP.unsqueeze(1)], dim=1)
            # contrastive_loss = ContrastiveLoss_s(all_source_con_features, source_label)
            # contrastive_loss = F.mse_loss(source_features, FFTP)
            # lossf = FFT_cls_loss + contrastive_loss

            # if epoch < 10:
            #     m = 0.1
            # else:
            #     m = 0.1



            # fft_cls_loss = crossEntropy(X2, source_label.cuda())
            # Loss Con_s
            # contrastive_loss = ContrastiveLoss_s(all_source_con_features, source_label)
            # # # Loss Con_t
            # contrastive_loss_t = ContrastiveLoss_t(all_target_con_features, pseudo_label_t)
            # Loss Occ
            domain_similar_loss = DSH_loss(source_out, target_out)
            # lossh = -torch.mean(F.softmax(target_outputs.cuda() + 1e-6) * torch.log(F.softmax(target_outputs.cuda() + 1e-6)))
            # lossh = Variable(lossh, requires_grad=True)

            # loss = cls_loss + 0.3 * lambd * lmmd_loss + 0.1 *contrastive_loss_s + 0.1 *contrastive_loss_t + domain_similar_loss
            loss = (cls_loss + a * lmmd_loss + domain_similar_loss)

            # Update parameters

            optimizers.zero_grad()
            loss.backward(retain_graph=True)

            optimizerf.zero_grad()
            FFT_cls_loss.backward()



            optimizers.step()
            optimizerf.step()

            pred = FFTX.data.max(1)[1]
            total_hit += pred.eq(source_label.data.cuda()).sum()
            size += source_label.data.size()[0]
            test_accuracy = 100. * float(total_hit) / size



            # if epoch % epochs == 0:
            #
            #     fake_label, true_label = utils.obtain_label(test_loader, feature_encoder)
            #
            #     cls_probs = torch.eye(CLASS_NUM)[true_label].sum(0)  ###################################
            #     cls_probs = cls_probs / cls_probs.sum()
            #
            #     pk_solver = PK_solver(true_label.shape[0], CLASS_NUM, pk_prior_weight=pk_prior_weight)
            #     if pk_type == 'ub':
            #         pk_solver.create_C_ub(cls_probs.cpu().numpy(), pk_uconf)
            #     elif pk_type == 'br':
            #         pk_solver.create_C_br(cls_probs.cpu().numpy(), pk_uconf)
            #     else:
            #         raise NotImplementedError
            #
            #     mem_label = obtain_label(fake_label.cpu(), true_label.cpu(), None, pk_solver)
            #     mem_label = torch.from_numpy(mem_label).cuda()
            #     mem_label = mem_label.long()
            #     mem_label = torch.eye(CLASS_NUM)[mem_label].cuda()

            # if epoch >= train_num:
            #     if i % len_clean_loader == 0:
            #         iter_clean = iter(clean_loader)
            #     clean_data, clean_label = iter_clean.next()
            #     clean_features, _, _, clean_outputs, _ = feature_encoder(clean_data.cuda())
            #     target_cls_loss = crossEntropy(clean_outputs, clean_label.cuda())
            #     optimizers.zero_grad()
            #     target_cls_loss.backward()
            #     optimizers.step()

        # print('epoch {:>3d}:   cls loss: {:6.4f},lmmd loss:{:6f}, occ loss:{:6f} con_s loss:{:6f}, con_t loss:{:6f},acc {:6.4f}, total loss: {:6.4f}'
        #       .format(epoch , cls_loss.item(),lmmd_loss.item(),domain_similar_loss.item(),contrastive_loss_s.item(),contrastive_loss_t.item(),
        #        total_hit / size,loss.item()))

        print('epoch {:>3d}:   cls loss: {:6.4f},lmmd loss:{:6f}, occ loss:{:6f} ,fft_cls_loss:{:6f} ,acc {:6.4f}, total loss: {:6.4f}'
              .format(epoch , cls_loss.item(),lmmd_loss.item(),domain_similar_loss.item(), domain_similar_loss.item(),
               total_hit / size,loss.item()))
        # print(
        #     'epoch {:>3d}:   cls loss: {:6.4f},lmmd loss:{:6f}, occ loss:{:6f} ,contrastive_loss:{:6f} ,acc {:6.4f}, total loss: {:6.4f}'
        #     .format(epoch, fft_cls_loss.item(), contrastive_loss.item(), contrastive_loss_t.item(), contrastive_loss.item(),
        #             total_hit / size, loss.item()))


        if epoch % epochs == 0:
            fake_label, p_label = utils.obtain_label(test_loader, feature_encoder)     ### fl （39335，7）  pl（39335）
            cls_probs = torch.eye(CLASS_NUM)[p_label].sum(0)  ###################################（7）每个样本数量
            cls_probs = cls_probs / cls_probs.sum()                    ##（7）每个样本比例

            pk_solver = PK_solver(p_label.shape[0], CLASS_NUM, pk_prior_weight=pk_prior_weight)
            if pk_type == 'ub':
                pk_solver.create_C_ub(cls_probs.cpu().numpy(), pk_uconf)
            elif pk_type == 'br':
                pk_solver.create_C_br(cls_probs.cpu().numpy(), pk_uconf)
            else:
                raise NotImplementedError

            mem_label = obtain_label(fake_label.cpu(), None, pk_solver)
            mem_label = torch.from_numpy(mem_label).cuda()
            mem_label = mem_label.long()
            mem_label = torch.eye(CLASS_NUM)[mem_label].cuda()
            # max_iter = epochs
            max_iter = interval_iter * turnnum
            iter_num = 0

            print('start pk')
            while iter_num < max_iter:

                if ema < 1.0 and iter_num > 0 and iter_num % interval_iter == 0:
                    feature_encoder.eval()
                    start_test = True
                    with torch.no_grad():
                        iter_test = iter(test_loader)
                        for i in range(len(test_loader)):
                            data = iter_test.next()
                            inputs = data[0]
                            inputs = inputs.cuda()
                            feas, _, _, outputs, _ = feature_encoder(inputs)
                            FFTP, FEAS = FFT_encoder(inputs)
                            outputs = nn.Softmax(dim=1)(outputs)
                            if start_test:
                                all_fea = FEAS.float().cpu()
                                all_output = outputs.float()
                                start_test = False
                            else:
                                all_fea = torch.cat((all_fea, feas.float().cpu()), 0)
                                all_output = torch.cat((all_output, outputs.float()), 0)
                        fake_label = fake_label.cuda() * ema + all_output.detach() * (1 - ema)
                    feature_encoder.train()

                    mem_label = obtain_label(fake_label.cpu(), all_fea, pk_solver)  ##############
                    mem_label = torch.from_numpy(mem_label).cuda()
                    mem_label = mem_label.long()
                    mem_label = torch.eye(CLASS_NUM)[mem_label].cuda()  ##################

                print('start turning')


                iter_targetidx = iter(test_loaderidx)
                inputs_target, y, tar_idx = iter_targetidx.next()
                # for i, (x, y) in enumerate(test_loader):
                #     inputs_target = x
                #     tar_idx = i

                if inputs_target.size(0) == 1:
                    continue

                iter_num += 1
                # lr_scheduler(optimizer, iter_num=iter_num, max_iter=max_iter, power=1.5)
                inputs_target = inputs_target.cuda()
                with torch.no_grad():
                    outputs_target_by_source = fake_label[tar_idx, :].cuda()
                    # _, src_idx = torch.sort(outputs_target_by_source, -1, descending=True)
                _, _, _, outputs_target, _ = feature_encoder(inputs_target)
                FFT_tp, _, = FFT_encoder(inputs_target)
                outputs_target = nn.Softmax(dim=1)(outputs_target)

                target = (mem_label[tar_idx, :] * 0.9 + 1 / mem_label.shape[-1] * 0.1)
                # target = outputs_target_by_source

                # classifier_loss = nn.KLDivLoss(reduction='batchmean')(outputs_target.log(), target)
                # optimizer.zero_grad()
                #
                # entropy_loss = torch.mean(loss.Entropy(outputs_target))
                # msoftmax = outputs_target.mean(dim=0)
                # gentropy_loss = torch.sum(- msoftmax * torch.log(msoftmax + 1e-5))
                # entropy_loss -= gentropy_loss
                # classifier_loss += entropy_loss

                classifier_loss = crossEntropy(outputs_target, target)
                optimizer.zero_grad()
                classifier_loss.backward(retain_graph=True)

                fftloss = crossEntropy(FFT_tp, target)
                optimizerff.zero_grad()
                fftloss.backward()

                optimizer.step()
                optimizerff.step()
                print(
                    'iter_num {:>3d}:   cls loss: {:6.4f}'
                    .format(iter_num, classifier_loss.item()))

            train_end = time.time()
            print("Testing ...")
            feature_encoder.eval()
            total_rewards = 0
            counter = 0
            multiprocess = DCD(num_classes=CLASS_NUM)
            accuracies = []
            predict = np.array([], dtype=np.int64)
            labels = np.array([], dtype=np.int64)
            with torch.no_grad():
                for test_datas, test_labels in test_loader:
                    batch_size = test_labels.shape[0]

                    test_features, _, _, test_outputs, _ = feature_encoder(Variable(test_datas).cuda())
                    test_outputsFFT, test_featuresFFT = FFT_encoder(Variable(test_datas).cuda())
                    evidence = multiprocess(test_outputs, test_outputsFFT)
                    pred = evidence.data.max(1)[1]

                    test_labels = test_labels.numpy()
                    rewards = [1 if pred[j] == test_labels[j] else 0 for j in range(batch_size)]

                    total_rewards += np.sum(rewards)
                    counter += batch_size

                    predict = np.append(predict, pred.cpu().numpy())
                    labels = np.append(labels, test_labels)

                    accuracy = total_rewards / 1.0 / counter  #
                    accuracies.append(accuracy)

            test_accuracy = 100. * total_rewards / len(test_loader.dataset)
            acc[iDataSet] = 100. * total_rewards / len(test_loader.dataset)
            OA = acc
            C = metrics.confusion_matrix(labels, predict)
            A[iDataSet, :] = np.diag(C) / np.sum(C, 1, dtype=np.float)

            k[iDataSet] = metrics.cohen_kappa_score(labels, predict)
            print('\t\tAccuracy: {}/{} ({:.2f}%)\n'.format(total_rewards, len(test_loader.dataset),
                                                           100. * total_rewards / len(test_loader.dataset)))
            test_end = time.time()

            # Training mode

            if test_accuracy > last_accuracy:
                # save networks
                # torch.save(feature_encoder.state_dict(),str("../checkpoints/DFSL_feature_encoder_" + "houston_cl_lmmd_dis_attention" +str(iDataSet) +".pkl"))
                print("save networks for epoch:", epoch + 1)
                last_accuracy = test_accuracy
                best_episdoe = epoch
                best_predict_all = predict
                best_G, best_RandPerm, best_Row, best_Column = G, RandPerm, Row, Column
                print('best epoch:[{}], best accuracy={}'.format(best_episdoe + 1, last_accuracy))

            print('iter:{} best epoch:[{}], best accuracy={}'.format(iDataSet, best_episdoe + 1, last_accuracy))
            print('***********************************************************************************')

AA = np.mean(A, 1)
AAMean = np.mean(AA,0)
AAStd = np.std(AA)
AMean = np.mean(A, 0)
AStd = np.std(A, 0)
OAMean = np.mean(acc)
OAStd = np.std(acc)
kMean = np.mean(k)
kStd = np.std(k)
print ("train time per DataSet(s): " + "{:.5f}".format(train_end-train_start))
print("test time per DataSet(s): " + "{:.5f}".format(test_end-train_end))
print ("average OA: " + "{:.2f}".format( OAMean) + " +- " + "{:.2f}".format( OAStd))
print ("average AA: " + "{:.2f}".format(100 * AAMean) + " +- " + "{:.2f}".format(100 * AAStd))
print ("average kappa: " + "{:.4f}".format(100 *kMean) + " +- " + "{:.4f}".format(100 *kStd))
print ("accuracy for each class: ")
for i in range(CLASS_NUM):
    print ("Class " + str(i) + ": " + "{:.2f}".format(100 * AMean[i]) + " +- " + "{:.2f}".format(100 * AStd[i]))


best_iDataset = 0
for i in range(len(acc)):
    print('{}:{}'.format(i, acc[i]))
    if acc[i] > acc[best_iDataset]:
        best_iDataset = i
print('best acc all={}'.format(acc[best_iDataset]))

#################classification map################################

for i in range(len(best_predict_all)):  # predict ndarray <class 'tuple'>: (9729,)
    best_G[best_Row[best_RandPerm[ i]]][best_Column[best_RandPerm[ i]]] = best_predict_all[i] + 1

hsi_pic = np.zeros((best_G.shape[0], best_G.shape[1], 3))
for i in range(best_G.shape[0]):
    for j in range(best_G.shape[1]):
        if best_G[i][j] == 0:
            hsi_pic[i, j, :] = [0, 0, 0]
        if best_G[i][j] == 1:
            hsi_pic[i, j, :] = np.array([147, 67, 46]) / 255.
        if best_G[i][j] == 2:
            hsi_pic[i, j, :] = np.array([0, 0, 255]) / 255.
        if best_G[i][j] == 3:
            hsi_pic[i, j, :] = np.array([255, 100, 0]) / 255.
        if best_G[i][j] == 4:
            hsi_pic[i, j, :] = np.array([0, 255, 123]) / 255.
        if best_G[i][j] == 5:
            hsi_pic[i, j, :] = np.array([164, 75, 155]) / 255.
        if best_G[i][j] == 6:
            hsi_pic[i, j, :] = np.array([101, 174, 255]) / 255.
        if best_G[i][j] == 7:
            hsi_pic[i, j, :] = np.array([118, 254, 172]) / 255.


utils.classification_map(hsi_pic[4:-4, 4:-4, :], best_G[4:-4, 4:-4], 96,  "classificationMap/ycycour.png")
