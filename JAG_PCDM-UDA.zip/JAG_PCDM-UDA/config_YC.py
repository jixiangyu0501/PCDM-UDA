nDataSet = 10

BATCH_SIZE = 128
epochs = 100
lr = 0.01
lrpk = 0.05
lrf = 0.005
CLASS_NUM = 7
nBand = 147
HalfWidth =  3
train_num = 40

momentum = 0.9
patch_size = 2 * HalfWidth + 1
no_cuda =False
cuda_id = '0'
l2_decay = 5e-4

#1121
seeds = [1421, 1120, 1535, 1124, 1121, 1112, 1117, 1128, 1129, 1588]
train_end = 0
test_end = 0

pk_prior_weight = 10.
pk_type = 'br'     ####ub br
pk_uconf = 1.0
pk_knn = 1
distance = 'cosine'
ema = 0.6
turnnum = 3
interval_iter = 40
a = 0.3