nDataSet = 10

BATCH_SIZE = 128
epochs = 100
lr = 0.05
lrf = 0.005
lrpk = 0.05
CLASS_NUM = 7
nBand = 48
HalfWidth = 3
train_num = 40

momentum = 0.9
patch_size = 2 * HalfWidth + 1
no_cuda = False
cuda_id = '0'
l2_decay = 5e-4
seeds = [1102, 1130, 1141, 1151, 1167, 1173, 1202, 1212, 1289, 1181]
train_end = 0
test_end = 0

pk_prior_weight = 10.
pk_type = 'ub'  ####ub br
pk_uconf = 1.0
pk_knn = 1
distance = 'cosine'
ema = 0.6
turnnum = 3
interval_iter = 40
a = 0
