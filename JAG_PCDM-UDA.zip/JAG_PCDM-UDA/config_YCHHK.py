nDataSet = 10

BATCH_SIZE = 128
epochs = 40
lr = 0.05
lrpk = 0.05
lrf = 0.005
CLASS_NUM = 6
nBand = 119
HalfWidth = 2
train_num = 40

momentum = 0.9
patch_size = 2 * HalfWidth + 1
no_cuda = False
cuda_id = '0'
l2_decay = 5e-4

seeds = [1110, 1108, 1114, 1115, 1118, 1133, 1127, 1001, 1372, 1116]

train_end = 0
test_end = 0

pk_prior_weight = 10.
pk_type = 'ub'  ####ub br
pk_uconf = 1.0
pk_knn = 1
distance = 'cosine'
ema = 0.6
turnnum = 3
interval_iter = 40
a = 0.3
